package com.example.myapplication.ui.theme

class Teal200 {

}
